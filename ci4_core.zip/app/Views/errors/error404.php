<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
<div class="card border-danger p-3 text-center">
	<h1 class="font-weight-bold">404</h1>
	<p>Halaman tidak ditemukan!</p>
</div>
<?= $this->endSection() ?>
